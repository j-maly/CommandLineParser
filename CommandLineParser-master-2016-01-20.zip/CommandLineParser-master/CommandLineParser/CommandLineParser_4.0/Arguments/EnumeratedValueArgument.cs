using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using CommandLineParser.Arguments;
using CommandLineParser.Exceptions;

namespace CommandLineParser.Arguments
{
    /// <summary>
    /// Use EnumeratedValueArgument for an argument whose values must be from certain finite set 
    /// (see <see cref="AllowedValues"/>)
    /// </summary>
    /// <typeparam name="TValue">Type of the value</typeparam>
    /// <include file='Doc\CommandLineParser.xml' path='CommandLineParser/Arguments/EnumeratedValueArgument/*'/>
    public class EnumeratedValueArgument<TValue>: 
        CertifiedValueArgument<TValue>
    {
        private ICollection<TValue> allowedValues;

        /// <summary>
        /// Set of values that are allowed for the argument.
        /// </summary>
        public ICollection<TValue> AllowedValues
        {
            get { return allowedValues; }
            set { allowedValues = value; }
        }

        /// <summary>
        /// Initilazes <see cref="AllowedValues"/> by a string of values separated by commas or semicolons.
        /// </summary>
        /// <param name="valuesString">Allowed values (separated by comas or semicolons)</param>
        public void InitAllowedValues(string valuesString)
        {
            string[] splitted = valuesString.Split(';', ',');
            TValue[] typedValues = new TValue[splitted.Length];
            int i = 0;
            foreach (string value in splitted)
            {
                typedValues[i] = Convert(value);
                i++;
            }
            AllowedValues = typedValues;
        }

        #region constructor

        /// <summary>
        /// Creates new command line argument with a <see cref="Argument.ShortName">short name</see>.
        /// </summary>
        /// <param name="shortName">Short name of the argument</param>
        public EnumeratedValueArgument(char shortName)
            : base(shortName)
        {
            this.allowedValues = new TValue[0];
        }

        /// <summary>
        /// Creates new command line argument with a <see cref="Argument.ShortName">short name</see>
        /// and <see cref="Argument.LongName">long name</see>.
        /// </summary>
        /// <param name="shortName">Short name of the argument</param>
        /// <param name="longName">Long name of the argument </param>
        public EnumeratedValueArgument(char shortName, string longName)
            : base(shortName, longName)
        {
            this.allowedValues = new TValue[0];
        }

        /// <summary>
        /// Creates new command line argument with a <see cref="Argument.ShortName">short name</see>.
        /// </summary>
        /// <param name="shortName">Short name of the argument</param>
        /// <param name="allowedValues">Allowed values</param>
        public EnumeratedValueArgument(char shortName, ICollection<TValue> allowedValues)
            : base(shortName)
        {
            this.allowedValues = allowedValues;
        }

        /// <summary>
        /// Creates new command line argument with a <see cref="Argument.ShortName">short name</see>
        /// and <see cref="Argument.LongName">long name</see>.
        /// </summary>
        /// <param name="shortName">Short name of the argument</param>
        /// <param name="longName">Long name of the argument </param>
        /// <param name="allowedValues">Allowed values</param>
        public EnumeratedValueArgument(char shortName, string longName, ICollection<TValue> allowedValues)
            : base(shortName, longName)
        {
            this.allowedValues = allowedValues;
        }

        /// <summary>
        /// Creates new command line argument with a <see cref="Argument.ShortName">short name</see>,
        /// <see cref="Argument.LongName">long name</see> and <see cref="Argument.Description">description</see>
        /// </summary>
        /// <param name="shortName">Short name of the argument</param>
        /// <param name="longName">Long name of the argument </param>
        /// <param name="description">Description of the argument</param>
        /// <param name="allowedValues">Allowed values</param>
        public EnumeratedValueArgument(char shortName, string longName, string description, ICollection<TValue> allowedValues)
            : base(shortName, longName, description)
        {
            this.allowedValues = allowedValues;
        }

        #endregion

        /// <summary>
        /// Checks whether the specified value belongs to 
        /// the set of <see cref="AllowedValues">allowed values</see>. 
        /// </summary>
        /// <param name="value">value to certify</param>
        /// <exception cref="CommandLineArgumentOutOfRangeException">thrown when <paramref name="value"/> does not belong to the set of allowed values.</exception>
        internal override void Certify(TValue value)
        {
            if (!allowedValues.Contains(Value))
                throw new CommandLineArgumentOutOfRangeException(String.Format(
                                                                     Messages.EXC_ARG_ENUM_OUT_OF_RANGE, Value,
                                                                     Name), Name);
        }
    }
    
    /// <summary>
    /// <para>
    /// Attribute for declaring a class' field a <see cref="EnumeratedValueArgument{TValue}"/> and 
    /// thus binding a field's value to a certain command line switch argument.
    /// </para>
    /// <para>
    /// Instead of creating an argument explicitly, you can assign a class' field an argument
    /// attribute and let the CommandLineParse take care of binding the attribute to the field.
    /// </para>
    /// </summary>
    /// <remarks>Appliable to fields and properties (public).</remarks>
    /// <remarks>Use <see cref="CommandLineParser.ExtractArgumentAttributes"/> for each object 
    /// you where you have delcared argument attributes.</remarks>
    /// <example>
    /// <code source="Examples\AttributeExample.cs" lang="cs" title="Example of declaring argument attributes" />
    /// </example>
    public sealed class EnumeratedValueArgumentAttribute : ArgumentAttribute
    {
        private Type argumentType;

        /// <summary>
        /// Creates proper generic <see cref="BoundedValueArgument{TValue}"/> type for <paramref name="type"/>.
        /// </summary>
        /// <param name="type">type of the argument value</param>
        /// <returns>generic type</returns>
        private static Type CreateProperValueArgumentType(Type type)
        {
            Type genericType = typeof(EnumeratedValueArgument<>);
            Type constructedType = genericType.MakeGenericType(type);
            return constructedType;
        }

        /// <summary>
		/// Creates new instance of EnumeratedValueArgumentAttribute. EnumeratedValueArgument
		/// uses underlaying <see cref="EnumeratedValueArgument{TValue}"/>.
        /// </summary>
        /// <param name="type">Type of the generic parameter of <see cref="EnumeratedValueArgument{TValue}"/>.</param>
        /// <param name="shortName"><see cref="Argument.ShortName">short name</see> of the underlying argument</param>
        /// <remarks>
        /// Parameter <paramref name="type"/> has to be either built-in 
        /// type or has to define a static Parse(String, CultureInfo) 
        /// method for reading the value from string.
        /// </remarks>
        public EnumeratedValueArgumentAttribute(Type type, char shortName)
            : base(CreateProperValueArgumentType(type), shortName)
        {
            argumentType = CreateProperValueArgumentType(type);
        }

        /// <summary>
		/// Creates new instance of EnumeratedValueArgument. EnumeratedValueArgument
		/// uses underlaying <see cref="EnumeratedValueArgument{TValue}"/>.
        /// </summary>
		/// <param name="type">Type of the generic parameter of <see cref="EnumeratedValueArgument{TValue}"/>.</param>
        /// <param name="shortName"><see cref="Argument.ShortName">short name</see> of the underlying argument</param>
        /// <param name="longName"><see cref="Argument.LongName">long name</see> of the underlying argument</param>
        /// <remarks>
        /// Parameter <paramref name="type"/> has to be either built-in 
        /// type or has to define a static Parse(String, CultureInfo) 
        /// method for reading the value from string.
        /// </remarks>
        public EnumeratedValueArgumentAttribute(Type type, char shortName, string longName)
            : base(CreateProperValueArgumentType(type), shortName, longName)
        {
            argumentType = CreateProperValueArgumentType(type);
        }

        /// <summary>
        /// Allowed values of the argument, separated by commas or semicolons.
        /// </summary>
        public string AllowedValues
        {
            get
            {
                return String.Empty;
            }
            set
            {
                argumentType.InvokeMember(
                    "InitAllowedValues", BindingFlags.InvokeMethod, null, Argument, new object[] {value});
            }
        }

        /// <summary>
        /// Default value
        /// </summary>
        public object DefaultValue
        {
            get
            {
                return argumentType.InvokeMember("DefaultValue", BindingFlags.GetProperty, null, Argument, null);
            }
            set
            {
                argumentType.InvokeMember("DefaultValue", BindingFlags.SetProperty, null, Argument, new[] { value });
            }
        }
    }
}