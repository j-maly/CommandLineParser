﻿namespace Tests
{
    /// <summary>
    /// For some reason the XUnit test runner blocks when running in ASPNET5 when multiple test classes are used
    /// </summary>
    public partial class Tests
    {
        public enum MyEnum
        {
            One,
            Two
        }
    }
}